// Simple hardcoded credentials for demo (replace with backend auth in production)
const DEMO_CRED = { id: "user1", password: "mypassword" };
let watchId = null;

document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const loginId = document.getElementById('loginId').value;
    const loginPass = document.getElementById('loginPass').value;
    if (loginId === DEMO_CRED.id && loginPass === DEMO_CRED.password) {
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('location-container').style.display = 'block';
        startTracking();
    } else {
        document.getElementById('loginError').innerText = 'Invalid ID or password';
    }
});

function startTracking() {
    if (!navigator.geolocation) {
        document.getElementById('status').innerText = 'Geolocation not supported.';
        return;
    }
    document.getElementById('status').innerText = 'Requesting location permissions...';

    watchId = navigator.geolocation.watchPosition(
        function(position) {
            document.getElementById('status').innerText = "Live location received!";
            document.getElementById('lat').innerText = position.coords.latitude;
            document.getElementById('lon').innerText = position.coords.longitude;
            // Here you can send the location to your database with AJAX/fetch if needed
        },
        function(error) {
            document.getElementById('status').innerText = 'Error getting location: ' + error.message;
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
}

function logout() {
    if (watchId) {
        navigator.geolocation.clearWatch(watchId);
    }
    document.getElementById('login-container').style.display = 'block';
    document.getElementById('location-container').style.display = 'none';
}
